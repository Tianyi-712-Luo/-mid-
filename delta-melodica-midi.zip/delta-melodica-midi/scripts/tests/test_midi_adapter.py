"""Synthetic tests use original test material, not copyrighted song fixtures."""

import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from midi_adapter import (AdaptationError, TempoMap, read_midi, build, fingerings,
                          load_selection, fit_register, validate_profile)
import mido

ROOT=Path(__file__).resolve().parents[2]


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.profile=json.loads((ROOT/"profiles/full-draft.json").read_text(encoding="utf-8"))

    def make_source(self,notes,tempos=None,ppq=480,extra=None,kind=1):
        path=self.root/"source.mid"
        mid=mido.MidiFile(type=kind,ticks_per_beat=ppq)
        meta=[]
        for tick,value in tempos or [(0,500000)]:
            meta.append((tick,-1,mido.MetaMessage("set_tempo",tempo=value)))
        note_events=[]
        for index,(on,off,pitch) in enumerate(notes):
            note_events.append((on,2,mido.Message("note_on",note=pitch,velocity=90)))
            note_events.append((off,1,mido.Message("note_off",note=pitch)))
        note_events.extend(extra or [])
        final=max([x[0] for x in meta+note_events]+[0])+480
        for events in [meta,note_events]:
            track=mido.MidiTrack()
            previous=0
            for tick,priority,msg in sorted(events,key=lambda e:e[:2]):
                track.append(msg.copy(time=tick-previous))
                previous=tick
            track.append(mido.MetaMessage("end_of_track",time=final-previous))
            mid.tracks.append(track)
        mid.save(path)
        return path

    def selection(self,path,shift=0):
        data=read_midi(path)
        return {"source_sha256":data["sha256"],"preferred_shift":shift,
                "notes":[{"source_id":n["source_id"],"section":"phrase"} for n in data["notes"]]}

    def run_build(self,path,selection=None,profile=None):
        return build(path,selection or self.selection(path),profile or self.profile,self.root/"output.mid")

    def test_tempo_piecewise_and_directed_rounding(self):
        clock=TempoMap(480,[(0,500000),(480,1000000),(960,250000)])
        self.assertAlmostEqual(clock.seconds_at(720),1.0)
        self.assertAlmostEqual(clock.seconds_at(1200),1.625)
        for tick in [0,1,479,480,481,959,960,961,1200]:
            self.assertEqual(clock.tick_at(clock.seconds_at(tick),"ceil"),tick)
            self.assertEqual(clock.tick_at(clock.seconds_at(tick),"floor"),tick)
        t=clock.seconds_at(700.2)
        self.assertEqual(clock.tick_at(t,"floor"),700)
        self.assertEqual(clock.tick_at(t,"ceil"),701)

    def test_multitempo_roundtrip_and_source_integrity(self):
        path=self.make_source([(0,450,60),(480,900,62),(960,1320,64)],
                              tempos=[(0,500000),(600,900000),(1000,300000)])
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        report=self.run_build(path)
        self.assertTrue(report["verification"]["passed"])
        self.assertEqual(report["verification"]["onset_error_ticks_max"],0)
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),digest)

    def test_minimum_hold_crosses_tempo_change(self):
        path=self.make_source([(470,475,60),(700,900,61)],tempos=[(0,500000),(480,1000000)])
        report=self.run_build(path)
        first=report["notes"][0]
        self.assertGreaterEqual(first["end_seconds"]-first["seconds"],.055)
        self.assertGreater(first["off"],480)

    def test_zero_velocity_note_on_release(self):
        path=self.make_source([],extra=[
            (0,2,mido.Message("note_on",note=60,velocity=80)),
            (480,1,mido.Message("note_on",note=60,velocity=0))])
        data=read_midi(path)
        self.assertEqual(len(data["notes"]),1)
        self.assertEqual(data["notes"][0]["off"],480)
        self.assertEqual(data["parse_issues"],[])

    def test_fifo_same_pitch_pairing_is_explicit(self):
        path=self.make_source([(0,240,60),(120,360,60)])
        data=read_midi(path)
        self.assertEqual([(n["on"],n["off"]) for n in data["notes"]],[(0,240),(120,360)])
        self.assertEqual(data["same_pitch_overlap_count"],1)

    def test_profile_mapping_endpoints_and_enharmonics(self):
        self.assertEqual({p for p in range(128) if fingerings(p,self.profile)},set(range(48,86)))
        narrow=json.loads((ROOT/"profiles/no-low-draft.json").read_text())
        self.assertEqual({p for p in range(128) if fingerings(p,narrow)},set(range(60,84)))
        self.assertTrue(all(f["octave"]>=0 for p in range(60,84) for f in fingerings(p,narrow)))
        no_comma=copy.deepcopy(self.profile)
        del no_comma["keys"][","]
        self.assertTrue(fingerings(84,no_comma))
        self.assertFalse(fingerings(85,no_comma))

    def test_uniform_octave_keeps_intervals(self):
        path=self.make_source([(0,400,76),(480,880,83),(960,1360,95)])
        report=self.run_build(path,self.selection(path,-12))
        self.assertEqual([n["pitch"] for n in report["notes"]],[64,71,83])
        self.assertEqual(report["verification"]["source_interval_changes"],[])

    def test_narrow_profile_keeps_attacks_without_dropping(self):
        path=self.make_source([(0,300,52),(480,800,64),(960,1300,83)])
        narrow=json.loads((ROOT/"profiles/no-low-draft.json").read_text())
        report=self.run_build(path,profile=narrow)
        self.assertEqual(len(report["notes"]),3)
        self.assertTrue(all(60<=n["pitch"]<=83 for n in report["notes"]))
        self.assertEqual([n["on"] for n in report["notes"]],[0,480,960])

    def test_repeated_notes_remain_separate_with_release(self):
        path=self.make_source([(0,480,60),(480,960,60),(960,1440,60)])
        report=self.run_build(path)
        self.assertEqual(len(report["notes"]),3)
        for a,b in zip(report["notes"],report["notes"][1:]):
            self.assertLess(a["off"],b["on"])
            self.assertGreaterEqual(b["seconds"]-a["end_seconds"],.014)

    def test_dense_attacks_fail_without_time_warp(self):
        path=self.make_source([(0,10,60),(12,22,62)])
        with self.assertRaisesRegex(AdaptationError,"timing-feasible"):
            self.run_build(path)
        self.assertFalse((self.root/"output.mid").exists())

    def test_wrong_source_hash_rejected(self):
        path=self.make_source([(0,100,60)])
        selection=self.selection(path)
        selection["source_sha256"]="wrong"
        with self.assertRaisesRegex(AdaptationError,"SHA-256"):
            self.run_build(path,selection)

    def test_simultaneous_and_duplicate_selection_rejected(self):
        path=self.make_source([(0,300,60),(0,300,64)])
        with self.assertRaisesRegex(AdaptationError,"simultaneous"):
            self.run_build(path)
        selection=self.selection(path)
        selection["notes"]=[selection["notes"][0]]*2
        with self.assertRaisesRegex(AdaptationError,"duplicate"):
            self.run_build(path,selection)

    def test_unmatched_and_dangling_events_rejected(self):
        path=self.make_source([],extra=[
            (0,2,mido.Message("note_on",note=60,velocity=80)),
            (480,1,mido.Message("note_off",note=64))])
        with self.assertRaisesRegex(AdaptationError,"pairing"):
            self.run_build(path)

    def test_nonzero_bend_requires_explicit_review(self):
        path=self.make_source([(0,400,60)],extra=[(0,0,mido.Message("pitchwheel",pitch=1200))])
        with self.assertRaisesRegex(AdaptationError,"expression"):
            self.run_build(path)
        selection=self.selection(path)
        selection["acknowledge_expression_loss"]=True
        report=self.run_build(path,selection)
        self.assertEqual(report["ignored_expression"]["unsupported_acknowledged"],["nonzero_pitch_bend"])

    def test_controller_120_requires_review(self):
        path=self.make_source([(0,400,60)],extra=[
            (200,0,mido.Message("control_change",control=120,value=0))])
        with self.assertRaisesRegex(AdaptationError,"expression"):
            self.run_build(path)

    def test_tempo_conflict_requires_review(self):
        path=self.make_source([(0,400,60)],tempos=[(0,500000),(0,600000)])
        with self.assertRaisesRegex(AdaptationError,"tempo events"):
            self.run_build(path)
        selection=self.selection(path)
        selection["acknowledge_tempo_conflicts"]=True
        self.assertTrue(self.run_build(path,selection)["verification"]["passed"])

    def test_missing_pitch_class_rejected_not_snapped(self):
        path=self.make_source([(0,400,61)])
        natural=copy.deepcopy(self.profile)
        natural["allowed_semitones"]=[0]
        with self.assertRaisesRegex(AdaptationError,"pitch class"):
            self.run_build(path,profile=natural)

    def test_type_two_rejected(self):
        path=self.make_source([(0,400,60)],kind=2)
        with self.assertRaisesRegex(AdaptationError,"Type 0/1"):
            read_midi(path)

    def test_source_overwrite_rejected(self):
        path=self.make_source([(0,400,60)])
        with self.assertRaisesRegex(AdaptationError,"overwrite"):
            build(path,self.selection(path),self.profile,path)

    def test_invalid_profile_rejected(self):
        profile=copy.deepcopy(self.profile)
        profile["timing_ms"]["minimum_hold"]=-1
        with self.assertRaisesRegex(AdaptationError,"profile"):
            validate_profile(profile)


if __name__=="__main__":
    unittest.main(verbosity=2)
