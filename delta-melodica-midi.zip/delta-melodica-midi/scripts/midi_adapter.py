"""Portable, offline MIDI adaptation. Requires mido; never sends device input."""

from __future__ import annotations

import argparse
from bisect import bisect_right
from collections import Counter, defaultdict, deque
import hashlib
import json
import math
from pathlib import Path

import mido


class AdaptationError(ValueError):
    pass


class TempoMap:
    def __init__(self, ppq, changes):
        if ppq <= 0:
            raise AdaptationError("SMPTE division is not supported.")
        self.ppq = ppq
        effective = {0: 500000}
        for tick, tempo in changes:
            if tempo <= 0:
                raise AdaptationError("Non-positive tempo.")
            effective[int(tick)] = int(tempo)
        self.ticks = sorted(effective)
        self.tempos = [effective[t] for t in self.ticks]
        self.seconds = [0.0]
        for i in range(1, len(self.ticks)):
            self.seconds.append(self.seconds[-1] + mido.tick2second(
                self.ticks[i]-self.ticks[i-1], ppq, self.tempos[i-1]))

    def seconds_at(self, tick):
        i = bisect_right(self.ticks, tick)-1
        return self.seconds[i] + mido.tick2second(tick-self.ticks[i], self.ppq, self.tempos[i])

    def tick_at(self, seconds, rounding="nearest"):
        if seconds < 0:
            raise AdaptationError("Negative absolute time.")
        i = bisect_right(self.seconds, seconds)-1
        # mido.second2tick rounds in some versions; use the exact scale for
        # directed rounding, which is necessary for hold/gap constraints.
        value = self.ticks[i] + (seconds-self.seconds[i])*1e6*self.ppq/self.tempos[i]
        if rounding == "ceil":
            return math.ceil(value-1e-8)
        if rounding == "floor":
            return math.floor(value+1e-8)
        return round(value)

    def serializable(self):
        return [{"tick": t, "tempo": p, "seconds": s}
                for t,p,s in zip(self.ticks,self.tempos,self.seconds)]


def note_name(pitch):
    return ("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")[pitch % 12] + str(pitch//12-1)


def read_midi(path):
    path = Path(path)
    mid = mido.MidiFile(path)
    if mid.type not in (0,1) or mid.ticks_per_beat <= 0:
        raise AdaptationError("Only synchronous Type 0/1 PPQ files are supported.")
    events, track_info = [], []
    for ti,track in enumerate(mid.tracks):
        tick = 0
        for ei,msg in enumerate(track):
            tick += msg.time
            events.append((tick,ti,ei,msg))
        track_info.append({"track":ti,"name":track.name,"end_tick":tick})
    events.sort(key=lambda e:e[:3])
    tempo = TempoMap(mid.ticks_per_beat, [(t,m.tempo) for t,_,_,m in events if m.type=="set_tempo"])
    active = defaultdict(deque)
    notes,meta,controls,issues = [],[],[],[]
    overlapping = 0
    tempo_values=defaultdict(set)
    for tick,ti,ei,msg in events:
        if msg.type=="set_tempo":
            tempo_values[tick].add(msg.tempo)
        if msg.is_meta:
            row = msg.dict()
            row.pop("time",None)
            meta.append({"tick":tick,"track":ti,"event_index":ei,**row})
        elif msg.type not in ("note_on","note_off"):
            row = msg.dict()
            row.pop("time",None)
            controls.append({"tick":tick,"track":ti,"event_index":ei,**row})
        if msg.type=="note_on" and msg.velocity>0:
            key = ti,msg.channel,msg.note
            if active[key]:
                overlapping += 1
            active[key].append((tick,msg.velocity,ei))
        elif msg.type=="note_off" or (msg.type=="note_on" and msg.velocity==0):
            key = ti,msg.channel,msg.note
            if not active[key]:
                issues.append(f"unmatched_note_off:{ti}:{ei}")
                continue
            start,velocity,idx = active[key].popleft()
            if tick <= start:
                issues.append(f"non_positive_note:{ti}:{idx}")
            notes.append({
                "source_id":f"{ti}:{idx}", "track":ti,"channel":msg.channel,"pitch":msg.note,
                "velocity":velocity,"on":start,"off":tick,
                "seconds":tempo.seconds_at(start),"end_seconds":tempo.seconds_at(tick),
                "beat":start/mid.ticks_per_beat,
            })
    for key,queue in active.items():
        if queue:
            issues.append(f"unclosed_note_on:{key}:{len(queue)}")
    notes.sort(key=lambda n:(n["on"],n["track"],n["pitch"],n["source_id"]))
    unsupported = []
    if any(c["type"]=="pitchwheel" and c["pitch"]!=0 for c in controls):
        unsupported.append("nonzero_pitch_bend")
    if any(c["type"]=="control_change" and c["control"] in (120,123) for c in controls):
        unsupported.append("all_notes_or_sound_off")
    if any(c["type"]=="sysex" for c in controls):
        unsupported.append("sysex")
    end_tick = max((e[0] for e in events),default=0)
    return {
        "source":str(path.resolve()),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "type":mid.type,"ppq":mid.ticks_per_beat,"end_tick":end_tick,
        "duration_seconds":tempo.seconds_at(end_tick),"tempo":tempo.serializable(),
        "tracks":track_info,"notes":notes,"metadata":meta,"controls":controls,
        "parse_issues":issues,"same_pitch_overlap_count":overlapping,
        "unsupported_expression":unsupported,
        "same_tick_tempo_conflicts":[{"tick":t,"values":sorted(v)}
                                    for t,v in tempo_values.items() if len(v)>1],
        "pedal_event_count":sum(c["type"]=="control_change" and c["control"]==64 for c in controls),
    }


def time_map(data):
    return TempoMap(data["ppq"],[(x["tick"],x["tempo"]) for x in data["tempo"]])


def stats(notes):
    if not notes:
        return {"notes":0}
    pitches = [n["pitch"] for n in notes]
    onsets = Counter(n["on"] for n in notes)
    active,peak = 0,0
    for tick,delta in sorted([(n["on"],1) for n in notes]+[(n["off"],-1) for n in notes]):
        active += delta
        peak = max(peak,active)
    union = []
    for n in sorted(notes,key=lambda n:n["seconds"]):
        if union and n["seconds"]<=union[-1][1]:
            union[-1][1]=max(union[-1][1],n["end_seconds"])
        else:
            union.append([n["seconds"],n["end_seconds"]])
    gaps = [{"start":a[1],"end":b[0],"seconds":b[0]-a[1]} for a,b in zip(union,union[1:])]
    starts = sorted({n["seconds"] for n in notes})
    return {
        "notes":len(notes),"unique_onsets":len(onsets),
        "chord_onsets":sum(v>1 for v in onsets.values()),"max_polyphony_key_off":peak,
        "range":[min(pitches),max(pitches)],
        "range_names":[note_name(min(pitches)),note_name(max(pitches))],
        "pitch_histogram":dict(sorted(Counter(pitches).items())),
        "first_on_seconds":min(starts),"last_off_seconds":max(n["end_seconds"] for n in notes),
        "minimum_ioi_seconds":min((b-a for a,b in zip(starts,starts[1:])),default=None),
        "minimum_hold_seconds":min(n["end_seconds"]-n["seconds"] for n in notes),
        "longest_gaps":sorted(gaps,key=lambda g:-g["seconds"])[:15],
    }


def fingerings(pitch,profile):
    base = profile["base_midi_pitch"]
    low,high = profile["pitch_range"]
    if not low<=pitch<=high:
        return []
    found=[]
    for octave in profile["allowed_octaves"]:
        for sharp in profile["allowed_semitones"]:
            for key,offset in profile["keys"].items():
                if base+12*octave+sharp+offset == pitch:
                    found.append({"key":key,"octave":octave,"sharp":sharp})
    return found


def validate_profile(profile):
    try:
        base=profile["base_midi_pitch"]
        low,high=profile["pitch_range"]
        if not all(type(v) is int for v in (base,low,high)) or not 0<=base<=127 or not 0<=low<=high<=127:
            raise ValueError("Invalid pitch range or base.")
        if not profile["allowed_octaves"] or any(type(x) is not int or x not in (-1,0,1)
                                                 for x in profile["allowed_octaves"]):
            raise ValueError("Unsupported octave state.")
        if not profile["allowed_semitones"] or any(type(x) is not int or x not in (0,1)
                                                   for x in profile["allowed_semitones"]):
            raise ValueError("Unsupported semitone state.")
        if not profile["keys"] or any(not isinstance(k,str) or len(k)!=1 or type(v) is not int
                                      for k,v in profile["keys"].items()):
            raise ValueError("Invalid key map.")
        for key in ("minimum_hold","different_key_gap","same_key_gap","modifier_gap"):
            value=profile["timing_ms"][key]
            if not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:
                raise ValueError(f"Invalid timing field: {key}")
    except (KeyError,TypeError,ValueError) as exc:
        raise AdaptationError(f"Invalid instrument profile: {exc}") from exc


def load_selection(data,selection):
    if selection.get("source_sha256") != data["sha256"]:
        raise AdaptationError("Selection belongs to a different source SHA-256.")
    if data["parse_issues"]:
        raise AdaptationError(f"Unresolved MIDI pairing errors: {data['parse_issues']}")
    if data["unsupported_expression"] and not selection.get("acknowledge_expression_loss",False):
        raise AdaptationError(f"Review unsupported expression first: {data['unsupported_expression']}")
    if data["same_tick_tempo_conflicts"] and not selection.get("acknowledge_tempo_conflicts",False):
        raise AdaptationError("Conflicting simultaneous tempo events require review.")
    by_id={n["source_id"]:n for n in data["notes"]}
    chosen=[]
    seen=set()
    for row in selection.get("notes",[]):
        source_id=row["source_id"]
        if source_id not in by_id or source_id in seen:
            raise AdaptationError(f"Unknown or duplicate selected ID: {source_id}")
        seen.add(source_id)
        n=by_id[source_id]
        if n["channel"]==9 and not selection.get("allow_percussion_as_pitched",False):
            raise AdaptationError("Percussion channel selected as pitched melody.")
        shift=row.get("preferred_shift",selection.get("preferred_shift",0))
        if not isinstance(shift,int):
            raise AdaptationError("Preferred shift must be an integer semitone count.")
        chosen.append(dict(n,section=row.get("section","unlabelled"),
                           preferred_pitch=n["pitch"]+shift,
                           rationale=row.get("rationale","selected_voice")))
    chosen.sort(key=lambda n:(n["on"],n["source_id"]))
    if not chosen:
        raise AdaptationError("An explicit, non-empty melody selection is required.")
    if len({n["on"] for n in chosen}) != len(chosen):
        raise AdaptationError("Resolve simultaneous selected attacks before building.")
    return chosen


def fit_register(notes,profile):
    if all(fingerings(n["preferred_pitch"],profile) for n in notes):
        return [dict(n,output_pitch=n["preferred_pitch"]) for n in notes]
    candidates=[[p for p in range(128) if (p-n["preferred_pitch"])%12==0 and fingerings(p,profile)]
                for n in notes]
    if not all(candidates):
        raise AdaptationError("Some selected pitch class is not supported; no notes were dropped.")
    previous=[abs(p-notes[0]["preferred_pitch"])/12*.18 for p in candidates[0]]
    parents=[]
    for i in range(1,len(notes)):
        a,b=notes[i-1],notes[i]
        desired=b["preferred_pitch"]-a["preferred_pitch"]
        boundary=(a["section"]!=b["section"] or b["seconds"]-a["end_seconds"]>.25)
        costs,back=[],[]
        for q in candidates[i]:
            options=[]
            for j,p in enumerate(candidates[i-1]):
                interval=q-p
                direction=4 if (interval>0)-(interval<0)!=(desired>0)-(desired<0) else 0
                shift_change=(q-b["preferred_pitch"])!=(p-a["preferred_pitch"])
                options.append(previous[j]+abs(interval-desired)+direction
                               +(1 if boundary else 4)*shift_change
                               +abs(q-b["preferred_pitch"])/12*.18)
            idx=min(range(len(options)),key=options.__getitem__)
            costs.append(options[idx])
            back.append(idx)
        previous=costs
        parents.append(back)
    indices=[min(range(len(previous)),key=previous.__getitem__)]
    for back in reversed(parents):
        indices.append(back[indices[-1]])
    indices.reverse()
    return [dict(n,output_pitch=group[idx]) for n,group,idx in zip(notes,candidates,indices)]


def transition(a,b,profile):
    timing=profile["timing_ms"]
    modifier_change=a["octave"]!=b["octave"] or a["sharp"]!=b["sharp"]
    gap=timing["different_key_gap"]
    if modifier_change:
        gap=max(gap,timing["modifier_gap"])
    if a["key"]==b["key"]:
        gap=max(gap,timing["same_key_gap"])
    cost=3*(a["octave"]!=b["octave"])+1.2*(a["sharp"]!=b["sharp"])+.2*(a["key"]==b["key"])
    return gap/1000,cost


def articulate(notes,profile,data):
    clock=time_map(data)
    hold=profile["timing_ms"]["minimum_hold"]/1000
    candidates=[fingerings(n["output_pitch"],profile) for n in notes]
    previous=[.1*(f["octave"]!=0) for f in candidates[0]]
    parents=[]
    for i in range(1,len(notes)):
        costs,back=[],[]
        for f in candidates[i]:
            options=[]
            for j,g in enumerate(candidates[i-1]):
                gap,cost=transition(g,f,profile)
                earliest=clock.tick_at(notes[i-1]["seconds"]+hold,"ceil")
                deadline=notes[i]["seconds"]-gap
                latest=clock.tick_at(deadline,"floor") if deadline>=0 else -1
                options.append(previous[j]+cost if earliest<=latest else math.inf)
            idx=min(range(len(options)),key=options.__getitem__)
            costs.append(options[idx])
            back.append(idx)
        if not any(math.isfinite(c) for c in costs):
            raise AdaptationError(f"No timing-feasible fingering at {notes[i]['seconds']:.6f}s; no onset moved.")
        previous=costs
        parents.append(back)
    indices=[min(range(len(previous)),key=previous.__getitem__)]
    for back in reversed(parents):
        indices.append(back[indices[-1]])
    indices.reverse()
    fingers=[group[idx] for group,idx in zip(candidates,indices)]
    result=[]
    for i,(n,f) in enumerate(zip(notes,fingers)):
        off=max(n["off"],clock.tick_at(n["seconds"]+hold,"ceil"))
        next_gap=None
        if i+1<len(notes):
            next_gap,_=transition(f,fingers[i+1],profile)
            off=min(off,clock.tick_at(notes[i+1]["seconds"]-next_gap,"floor"))
        if off<=n["on"] or clock.seconds_at(off)-n["seconds"]+1e-9<hold:
            raise AdaptationError("Duration constraint failed after tick rounding.")
        if off>data["end_tick"]:
            raise AdaptationError("Minimum hold would extend the source file duration.")
        result.append(dict(n,source_pitch=n["pitch"],source_off=n["off"],
                           source_end_seconds=n["end_seconds"],
                           pitch=n["output_pitch"],off=off,end_seconds=clock.seconds_at(off),
                           fingering=f,next_gap_seconds=next_gap))
    return result


def export_midi(source_path,data,notes,output):
    output=Path(output)
    if output.resolve()==Path(source_path).resolve():
        raise AdaptationError("Refusing to overwrite the source.")
    original=mido.MidiFile(source_path)
    target=mido.MidiFile(type=0,ticks_per_beat=data["ppq"])
    events=[(0,-10,0,0,mido.MetaMessage("track_name",name="MELODY"))]
    # Lyrics/text/sequencer blobs are not execution instructions. Omit them
    # from the device file; preserve timing/meter metadata without guessing.
    for ti,track in enumerate(original.tracks):
        tick=0
        for ei,msg in enumerate(track):
            tick+=msg.time
            if msg.is_meta and msg.type in ("set_tempo","time_signature","key_signature"):
                if msg.type=="key_signature" and any((n["pitch"]-n["source_pitch"])%12 for n in notes):
                    continue
                events.append((tick,-8,ti,ei,msg.copy(time=0)))
    events.append((0,-5,0,0,mido.Message("program_change",channel=0,program=22)))
    for i,n in enumerate(notes):
        events.append((n["on"],2,0,i,mido.Message("note_on",channel=0,note=n["pitch"],velocity=n["velocity"])))
        events.append((n["off"],1,0,i,mido.Message("note_off",channel=0,note=n["pitch"],velocity=0)))
    events.append((data["end_tick"],10,0,0,mido.MetaMessage("end_of_track")))
    track=mido.MidiTrack()
    previous=0
    for tick,priority,ti,ei,msg in sorted(events,key=lambda x:x[:4]):
        track.append(msg.copy(time=tick-previous))
        previous=tick
    target.tracks.append(track)
    output.parent.mkdir(parents=True,exist_ok=True)
    target.save(output)


def validate_export(data,arranged,output,profile):
    parsed=read_midi(output)
    actual=parsed["notes"]
    errors=[]
    if parsed["parse_issues"]:
        errors.extend(parsed["parse_issues"])
    if parsed["ppq"]!=data["ppq"] or parsed["tempo"]!=data["tempo"]:
        errors.append("tempo_or_ppq_changed")
    if parsed["end_tick"]!=data["end_tick"]:
        errors.append("file_duration_changed")
    if len(actual)!=len(arranged):
        errors.append("note_count_changed")
    for a,b in zip(arranged,actual):
        if any(a[k]!=b[k] for k in ("on","off","pitch","velocity")):
            errors.append(f"round_trip_mismatch:{a['source_id']}")
        if not fingerings(b["pitch"],profile):
            errors.append(f"unplayable:{a['source_id']}")
    if any(a["off"]>=b["on"] for a,b in zip(actual,actual[1:])):
        errors.append("overlap_or_missing_release_gap")
    if errors:
        raise AdaptationError(str(errors))
    intervals=[]
    for a,b in zip(arranged,arranged[1:]):
        original=b["source_pitch"]-a["source_pitch"]
        out=b["pitch"]-a["pitch"]
        if original!=out:
            intervals.append({"source_id":b["source_id"],"seconds":b["seconds"],
                              "source_interval":original,"output_interval":out})
    return {
        "passed":True,"selected_notes":len(actual),"onset_error_ticks_max":0,
        "source_interval_comparisons":max(0,len(actual)-1),
        "source_interval_changes":intervals,
        "pitch_class_retention_vs_source":sum((n["pitch"]-n["source_pitch"])%12==0 for n in arranged)/len(arranged),
        "pitch_class_retention_vs_preferred":sum((n["pitch"]-n["preferred_pitch"])%12==0 for n in arranged)/len(arranged),
        "tail_shortened":sum(n["off"]<n["source_off"] for n in arranged),
        "tail_extended":sum(n["off"]>n["source_off"] for n in arranged),
        "output_stats":stats(actual),
    }


def build(source,selection,profile,output):
    source=Path(source)
    output=Path(output)
    if source.resolve()==output.resolve():
        raise AdaptationError("Output must not overwrite the source.")
    validate_profile(profile)
    data=read_midi(source)
    chosen=load_selection(data,selection)
    arranged=articulate(fit_register(chosen,profile),profile,data)
    export_midi(source,data,arranged,output)
    verification=validate_export(data,arranged,output,profile)
    if hashlib.sha256(source.read_bytes()).hexdigest()!=data["sha256"]:
        raise AdaptationError("Source changed during conversion.")
    return {
        "source":str(source.resolve()),"source_sha256":data["sha256"],
        "source_note_count":len(data["notes"]),"source_duration_seconds":data["duration_seconds"],
        "selection_review":selection.get("review_status","unspecified"),
        "profile":profile,"output":str(output.resolve()),
        "output_sha256":hashlib.sha256(output.read_bytes()).hexdigest(),
        "verification":verification,"notes":arranged,
        "limitations":["MIDI static verification only; no in-game audio test.",
                       "Selection recall against an authoritative melody is not measured.",
                       "Fingering plan is advisory; MIDI does not encode mouse buttons."],
        "ignored_expression":{"pedal_events":data["pedal_event_count"],
                              "unsupported_acknowledged":data["unsupported_expression"]},
    }


def write_json(path,data):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="command",required=True)
    inspect=sub.add_parser("inspect",help="Read events; does not claim to extract the correct melody.")
    inspect.add_argument("source",type=Path)
    inspect.add_argument("--output",required=True,type=Path)
    create=sub.add_parser("build",help="Adapt an explicit source-bound melody selection.")
    create.add_argument("source",type=Path)
    create.add_argument("--selection",required=True,type=Path)
    create.add_argument("--profile",required=True,type=Path)
    create.add_argument("--output",required=True,type=Path)
    create.add_argument("--report",required=True,type=Path)
    args=parser.parse_args()
    try:
        if args.command=="inspect":
            if args.output.resolve()==args.source.resolve():
                raise AdaptationError("Inspection output must not overwrite source.")
            data=read_midi(args.source)
            data["summary"]=stats(data["notes"])
            write_json(args.output,data)
            print(json.dumps(data["summary"],ensure_ascii=False))
        else:
            paths=[args.source,args.selection,args.profile,args.output,args.report]
            if len({p.resolve() for p in paths}) != len(paths):
                raise AdaptationError("Input, output and report paths must be distinct.")
            selection=json.loads(args.selection.read_text(encoding="utf-8"))
            profile=json.loads(args.profile.read_text(encoding="utf-8"))
            report=build(args.source,selection,profile,args.output)
            write_json(args.report,report)
            print(json.dumps({"output":str(args.output),"notes":len(report["notes"]),
                              "static_verified":True},ensure_ascii=False))
    except (AdaptationError,KeyError,TypeError) as exc:
        parser.exit(2,f"ERROR: {exc}\n")


if __name__=="__main__":
    main()
