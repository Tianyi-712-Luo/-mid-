# 文件契约与实现边界

## Selection

`inspect` 的每个音符都有稳定的 `source_id=轨道索引:note_on事件索引`。它只对 SHA-256 完全相同的源文件有效。重新导出源 MIDI 后必须重新生成选择记录。

```json
{
  "source_sha256": "这里填写 inspect 生成的 SHA-256",
  "review_status": "说明完成了哪些声部复核，哪些尚未完成",
  "preferred_shift": 0,
  "notes": [
    {
      "source_id": "1:7",
      "section": "opening",
      "rationale": "说明为何选择该音",
      "preferred_shift": 0
    }
  ]
}
```

上面的 ID 只是格式示例，不是可套用到任何歌曲的真实选择。`preferred_shift` 的单位是半音，逐音字段优先于文件字段。优先采用全局或整句相同位移，不用它任意逐音改旋律。

脚本不会选择主旋律：它要求明确选择表，并拒绝未知/重复 ID、同 tick 多个选中音、未配对音、误选鼓通道。暂不自动合并同刻同音重复，调用方应先检查并选择/规范化。

`acknowledge_expression_loss: true` 仅表示已人工审阅非零弯音、SysEx、CC120/123 后接受相应损失，不代表脚本已实现这些发声语义。打击乐确实被有意视为固定音高时才可设置 `allow_percussion_as_pitched: true`。

源文件同 tick 存在不同 tempo 值时，先检查事件顺序与意图。确认继续保留源事件稳定顺序后，显式设置 `acknowledge_tempo_conflicts: true`；不能默认吞掉冲突。

## Profile

配置必须提供：

- `base_midi_pitch`：基准 Z 的 MIDI 音高。
- `pitch_range`：输出 MIDI 的上下限，包含边界。
- `allowed_octaves`：合法八度状态，通常为 -1、0、1 的子集。
- `allowed_semitones`：通常为 0、1；没有半音支持时只能为 0。
- `keys`：物理键到基准半音偏移的字典。
- `timing_ms`：minimum_hold、different_key_gap、same_key_gap、modifier_gap。
- `calibrated` 与证据文字：区分假设和实测。

脚本按合法指法枚举实际音高集合。即使区间连续，没有半音能力时也可能存在空洞；缺少某个音级会报错，不替换成最近自然音。

只更改文字上下限不能让硬件产生新音。播放器可用集合和游戏物理范围应分别确认。低八度兼容 profile 明确排除了 `octave=-1`，不是仅把音符数值限制到 60 以上。

## 时间和导出

内置 `TempoMap` 保留各段的 tick、tempo、累计秒，并支持有方向的秒→tick 舍入。无显式 tempo 时按 MIDI 默认 500000 微秒/四分音符计算。同刻多个 tempo 按源事件稳定顺序应用；冲突会记录并要求审阅。

输出 Type 0 单轨 `MELODY`，沿用 PPQ、tempo、拍号和结尾 tick。八度移调保留调号；非八度移调时当前脚本省略旧调号，避免留下错误标签，需要精确调号时由调用方补充。

移除踏板、弯音和其他控制器，不把钢琴延音变成长吹音。试听 program 22 只是本地 MIDI 音色，不能改变游戏音色。

如果设备最低保持时间会延长文件末尾，脚本报错而不是悄悄延长曲长。输入、选择表、profile、MIDI 输出和 JSON 报告路径必须不同。

## 输出报告

包含逐音来源、原始/输出音高、原始/输出音尾、指法候选路径、下一个音的安全间隔、目标配置、原文件和输出文件哈希。

`selected_notes` 和 `onset_error_ticks_max` 只评价已经选择的音符。它们不评价被排除的原谱音是否本该属于旋律。必须另做声部复核。

`source_interval_changes` 列出所有相邻音程变化。`pitch_class_retention_vs_source` 与 `...vs_preferred` 分开，允许用户主动整体转调时不会错误宣称原音级保留。

`longest_gaps` 使用 note_off，不是包含踏板的实际响度包络。没有游戏录音时不能把这些空白称作“实机漏音”。

## 测试边界

单元测试覆盖多速度段、定向 tick 舍入、note_on 零力度、FIFO 配对、能力边界、同键重触发、极密起音拒绝、源哈希绑定、音高与起音回读，以及控制器损失阻断。

这些测试不证明自动声部判断正确、不证明最佳听感，也不替代真实游戏响应测量。需要在新环境实际运行测试，不能照抄本包开发时的测试数量声称自己已验证。
